'use client'

import { useState, useCallback, useEffect } from "react";
import Link from "next/link";
import SingleSelect from "@/app/component/SingleSelect";
import DateSelector from "@/app/component/DateSelector";
import toast, { Toaster } from "react-hot-toast";
import { ArrowLeft, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { addCustomer, importCustomer } from "@/store/customer";
import { customerAllDataInterface, customerImportDataInterface } from "@/store/customer.interface";
import { getCampaign } from "@/store/masters/campaign/campaign";
import { getTypes, getTypesByCampaign } from "@/store/masters/types/types";
import { getCity } from "@/store/masters/city/city";
import { getLocation } from "@/store/masters/location/location";
import { handleFieldOptions } from "@/app/utils/handleFieldOptions";
import { getSubtype, getSubtypeByCampaignAndType } from "@/store/masters/subtype/subtype";
import { getSkill } from "@/store/masters/skill/skill";
import BackButton from "@/app/component/buttons/BackButton";
import SaveButton from "@/app/component/buttons/SaveButton";
import { handleFieldOptionsObject } from "@/app/utils/handleFieldOptionsObject";
import ObjectSelect from "@/app/component/ObjectSelect";
import CustomerSubtypeAdd from "@/app/masters/customer-subtype/add/page";
import { useCustomerImport } from "@/context/CustomerImportContext";
import LoaderCircle from "@/app/component/LoaderCircle";
import InvalidimportData from "@/app/component/popups/invalidImportData";
import {  CustomerAdvInterface, customerAssignInterface, customerGetDataInterface, DeleteDialogDataInterface } from "@/store/customer.interface";

interface ErrorInterface {
    [key: string]: string;
}

export default function SelectImports() {
    const [customerData, setCustomerData] = useState<customerImportDataInterface>({
        Campaign: { id: "", name: "" },
        CustomerType: { id: "", name: "" },
        customerName: "",
        CustomerSubtype: { id: "", name: "" },
        ContactNumber: "",
        City: "",
        Location: "",
        Experience: "",
        Adderess: "",
        Email: "",
        Skill: "",
        ReferenceId: "",
        CustomerId: "",
        CustomerDate: "",
        CustomerYear: "",
        Other: "",
        Description: "",
        Video: "",
        GoogleMap: "",
        Verified: "",
    });
    const [fieldOptions, setFieldOptions] = useState<Record<string, any[]>>({});
    const [fieldMapping, setFieldMapping] = useState<Record<string, string>>({});
    const [importLoader, setImportLoader] = useState(false);
      const [isTableDialogOpen, setIsTableDialogOpen] = useState(false);
  const [tableDialogcustomerData, setTableDialogCustomerData] = useState<customerGetDataInterface[]>([]);


    const [imagePreviews, setImagePreviews] = useState<string[]>([]);
    const [sitePlanPreview, setSitePlanPreview] = useState<string>("");
    const [errors, setErrors] = useState<ErrorInterface>({});
    const router = useRouter();
    const { excelHeaders, file } = useCustomerImport();
const [pendingValidData, setPendingValidData] = useState<any[]>([]);
    useEffect(() => {
        if (excelHeaders.length === 0) {
            // user opened this page directly
            router.push("/imports/customer");
        }
    }, [excelHeaders]);

    const normalizeHeader = (value: string) => {
    return value
        ?.toLowerCase()
        .replace(/\s+/g, "")       // remove spaces
        .replace(/[^a-z0-9]/g, ""); // remove special characters
};

useEffect(() => {
    if (!excelHeaders?.length) return;

    const autoMapped: Record<string, string> = {};

    excelHeaders.forEach((excelHeader) => {
        const normalizedExcel = normalizeHeader(excelHeader);

        const matchedField = mappingFields.find((field) => {
            return normalizeHeader(field) === normalizedExcel;
        });

        if (matchedField) {
            autoMapped[excelHeader] = matchedField;
        }
    });

    setFieldMapping(autoMapped);
}, [excelHeaders]);


    // 🟩 Handle Input
    const handleInputChange = useCallback(
        (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
            const { name, value } = e.target;
            setCustomerData((prev) => ({ ...prev, [name]: value }));
            setErrors((prev) => ({ ...prev, [name]: "" }));
        },
        []
    );

    const handleSelectChange = useCallback(
        (label: string, selected: string) => {
            setCustomerData((prev) => ({ ...prev, [label]: selected }));
            setErrors((prev) => ({ ...prev, [label]: "" }));
        },
        []
    );


    // Validate Form
    const validateForm = () => {
        const newErrors: ErrorInterface = {};
        if (!customerData.Campaign?.name.trim())
            newErrors.Campaign = "Campaign is required";
        if (!customerData.CustomerType?.name.trim())
            newErrors.CustomerType = "Customer Type is required";
        if (!customerData.CustomerSubtype?.name.trim())
            newErrors.CustomerSubtype = "Customer Subtype is required";
        return newErrors;
    };

    //Submit Form
    const handleSubmit = async () => {
        try{
            setImportLoader(true);
             const formData = new FormData();
              formData.append("fieldMapping", JSON.stringify(fieldMapping));
               if (file) {
            formData.append("file", file);    };
                // api calling 
                 const result = await importCustomer(formData);
                 const invalidCount = result?.invalid?.length || 0;
                 const importedCount = result?.imported?.length || 0;

                
        if(invalidCount > 0){
                setTableDialogCustomerData(result.invalid);
                 setPendingValidData(result.imported || []);
            setIsTableDialogOpen(true);
           
            toast.error(`${result.invalid.length} records not imported`);
            setImportLoader(false);      
 return;
        };
        if(importedCount > 0){
            toast.success("Customer imported successfully!");
             setImportLoader(false);
             setTimeout(()=>{
                 router.push("/customer");
             },300)
              
               return;
        };
         toast.error("Failed to import customer");
         setImportLoader(false);
        }catch(error){
             console.error("Customer import error:", error);
    toast.error("Failed to import customer");
    setImportLoader(false);
        }


        //  toast.error("Error importing customer");
        // console.error("Customer import Error:", error);
       
    };

    const finalizeValidImport = () => {
  if (pendingValidData.length > 0) {
    toast.success(`${pendingValidData.length} customers imported`);
    router.push("/customer");
  }
};
    const dropdownOptions = ["Option1", "Option2", "Option3"];

    // Object-based fields (for ObjectSelect)
    const objectFields = [
        { key: "Campaign", fetchFn: getCampaign },
        { key: "CustomerType", staticData: [] },
        { key: "CustomerSubtype", staticData: [] } // dependent

    ];

    // Simple array fields (for normal Select)
    const arrayFields = [
        { key: "Verified", staticData: ["yes", "no"] },
        { key: "Gender", staticData: ["male", "female", "other"] },
        { key: "City", fetchFn: getCity },
        { key: "Skill", fetchFn: getSkill },
        { key: "Location", fetchFn: getLocation },
    ];


    useEffect(() => {
        const loadFieldOptions = async () => {
            await handleFieldOptionsObject(objectFields, setFieldOptions);
            await handleFieldOptions(arrayFields, setFieldOptions);
        };
        loadFieldOptions();
    }, []);


    useEffect(() => {
        if (customerData.Campaign.id) {
            fetchCustomerType(customerData.Campaign.id);
        } else {
            setFieldOptions((prev) => ({ ...prev, CustomerType: [] }));
        }

        if (customerData.Campaign.id && customerData.CustomerType.id) {
            fetchCustomerSubType(customerData.Campaign.id, customerData.CustomerType.id);
        } else {
            setFieldOptions((prev) => ({ ...prev, CustomerSubtype: [] }));
        }
    }, [customerData.Campaign.id, customerData.CustomerType.id]);

    const fetchCustomerType = async (campaignId: string) => {
        try {
            const res = await getTypesByCampaign(campaignId);
            setFieldOptions((prev) => ({ ...prev, CustomerType: res || [] }));
        } catch (error) {
            console.error("Error fetching types:", error);
            setFieldOptions((prev) => ({ ...prev, CustomerType: [] }));
        }
    };

    const fetchCustomerSubType = async (campaignId: string, customertypeId: string) => {
        try {
            const res = await getSubtypeByCampaignAndType(campaignId, customertypeId);
            setFieldOptions((prev) => ({ ...prev, CustomerSubtype: res || [] }));
        } catch (error) {
            console.error("Error fetching types:", error);
            setFieldOptions((prev) => ({ ...prev, CustomerSubtype: [] }));
        }
    };

    const mappingFields = [
        "Campaign",
        "CustomerType",
        "CustomerSubType",
        "customerName",
        "ContactNumber",
        "City",
        "Location",
        "Experience",
        "Adderess",
        "Email",
        "Facillities ",
        "Skill",
        "ReferenceId",
        "CustomerId",
        "CustomerDate",
        "CustomerYear",
        "Other",
        "URL",
        "SalaryRange",
        "Description",
        "Video",
        "GoogleMap",
        "Verified",
    ];


    return (
        <div className=" min-h-screen flex justify-center">
            <InvalidimportData
             isOpen={isTableDialogOpen}
        title="Customers By"
        data={tableDialogcustomerData}
        onClose={() => {
          setIsTableDialogOpen(false)
         finalizeValidImport();
        }}
            />
            <Toaster position="top-right" />
            <div className="w-full">
                <div className="flex justify-end mb-4">
                    <BackButton
                        url="/customer"
                        text="Back"
                        icon={<ArrowLeft size={18} />}
                    />
                </div>

                <div className="bg-white backdrop-blur-lg p-10 w-full rounded-3xl shadow-2xl h-auto">
                    <form onSubmit={(e) => e.preventDefault()} className="w-full">
                        <div className="mb-8 text-left border-b pb-4 border-gray-200">
                            <h1 className="text-3xl font-extrabold text-[var(--color-secondary-darker)] leading-tight tracking-tight">
                                Customer <span className="text-[var(--color-primary)]">Selected Imports</span>
                            </h1>
                        </div>

                        <h2 className=" text-xl font-semibold text-gray-700 my-5 mt-10">Map Fields</h2>
                        <div className="grid grid-cols-2 max-md:grid-cols-1 gap-4 mt-5">
                            {excelHeaders.map((header) => {
                                /* if(header==="Campaign" || header==="Customer Type" || header==="Property Type" || header==="Customer Subtype")
                                    return null; */
                                return <div key={header} className="flex flex-col">
                                    <label className="text-sm font-medium mb-4">{header}</label>

                                    <SingleSelect
                                        label="Map To"
                                        options={mappingFields}
                                        value={fieldMapping[header] || ""}
                                        onChange={(value) =>
                                            setFieldMapping((prev) => ({
                                                ...prev,
                                                [header]: value,
                                            }))
                                        }
                                    />


                                </div>
                            })}
                        </div>

                        <div className="flex justify-end mt-4">

                            <SaveButton text={` ${importLoader ? "Saving.." : "Save Import"}`} icon={importLoader&&<LoaderCircle/>} onClick={handleSubmit} />

                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}


const InputField: React.FC<{
    label: string;
    name: string;
    value: string;
    error?: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
}> = ({ label, name, value, onChange, error }) => (
    <label className="relative block w-full">
        <input
            type="text"
            name={name}
            value={value}
            onChange={onChange}
            placeholder=" "
            className={`peer w-full border rounded-sm bg-transparent py-3 px-4 outline-none 
        ${error ? "border-red-500 focus:border-red-500" : "border-gray-400 focus:border-blue-500"}`}
        />
        <p className={`absolute left-2 bg-white px-1 text-gray-500 text-sm transition-all duration-300
      ${value || error ? "-top-2 text-xs text-blue-500" : "peer-placeholder-shown:top-3 peer-placeholder-shown:text-base peer-placeholder-shown:text-gray-400 peer-focus:-top-2 peer-focus:text-xs peer-focus:text-blue-500"}`}>
            {label}
        </p>
        {error && <span className="text-red-500 text-sm mt-1 block">{error}</span>}
    </label>
);

// Textarea field
const TextareaField: React.FC<{
    label: string;
    name: string;
    value: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
}> = ({ label, name, value, onChange }) => (
    <label className="relative block w-full">
        <textarea
            name={name}
            value={value}
            onChange={onChange}
            placeholder=" "
            className="peer w-full border rounded-sm border-gray-400 bg-transparent py-3 px-4 outline-none focus:border-blue-500 min-h-[100px]"
        ></textarea>
        <p className={`absolute left-2 bg-white px-1 text-gray-500 text-sm transition-all duration-300
      ${value ? "-top-2 text-xs text-blue-500" : "peer-placeholder-shown:top-3 peer-placeholder-shown:text-base peer-placeholder-shown:text-gray-400 peer-focus:-top-2 peer-focus:text-xs peer-focus:text-blue-500"}`}>
            {label}
        </p>
    </label>
);

// File upload with preview and remove
const FileUpload: React.FC<{
    label: string;
    multiple?: boolean;
    previews?: string[];
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onRemove?: (index: number) => void;
}> = ({ label, multiple, previews = [], onChange, onRemove }) => (
    <div className="flex flex-col">
        <label className="font-semibold text-gray-700 mb-2">{label}</label>
        <input
            type="file"
            multiple={multiple}
            onChange={onChange}
            className="border border-gray-300 rounded-md p-2"
        />
        {previews.length > 0 && (
            <div className="flex flex-wrap gap-3 mt-3">
                {previews.map((src, index) => (
                    <div key={index} className="relative">
                        <img
                            src={src}
                            alt={`preview-${index}`}
                            className="w-24 h-24 object-cover rounded-md border"
                        />
                        {onRemove && (
                            <button
                                type="button"
                                onClick={() => onRemove(index)}
                                className="absolute top-[-8px] right-[-8px] bg-red-600 text-white rounded-full p-1 hover:bg-red-700"
                            >
                                <X size={14} />
                            </button>
                        )}
                    </div>
                ))}
            </div>
        )}
    </div>
);